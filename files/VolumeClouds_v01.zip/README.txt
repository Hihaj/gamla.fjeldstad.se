
VolumeClouds v0.1
Anders Fjeldstad, andfj645@student.liu.se
2006-01-10



BESKRIVNING
================================================================================
VolumeClouds �r ett litet demo som visar en implementation av en volymrendering
av procedurella moln med sj�lvskuggning. I detta arkiv finns b�de k�llkod och
k�rbara filer (f�r Windows).

VolumeClouds �r skrivet i OpenGL/GLSL/C++. Jag har bifogat en Dev-C++-projektfil
som g�r att det ska vara l�tt att sj�lv kompilera k�llkoden om man vill �ndra
n�gra parametrar eller liknande. Programmet kr�ver att GLEW och GLFW finns
installerat om du vill kompilera det sj�lv. 

VolumeClouds kr�ver ett grafikkort som st�djer OpenGL 2.0 f�r att fungera. Det
�r dessutom l�ngsamt i och med att jag inte lagt energi p� att accelerera
noiseber�kningar och annat, s� man f�r vara beredd p� att det inte renderar
i s� h�g hastighet p� dagens vanliga hemdatorer.



INSTRUKTIONER F�R ANV�NDNING AV PROGRAMMET
================================================================================
N�r du startat programmet ser du ett f�nster med storlek 400x300 pixlar d�r ett
moln renderats mot en bl� bakgrund. En otroligt vacker sol finns ocks� med f�r
att upplevelsen ska bli fullkomlig... 

Du kan rotera scenen genom att h�lla nere
v�nster musknapp och flytta musen (observera att beroende p� din dators
prestanda kan programmet vara lite l�ngsamt p� att svara, s� forts�tt h�ll nere
musknappen �ven om inget h�nder direkt). N�r du snurrar p� scenen �r du i 
"interaktionsl�ge", vilket inneb�r att scenen bara renderas som en enklare
modell d�r du ser molnets grova form tillsammans med en upps�ttning koordinat-
axlar. Sl�pper du musknappen s� upph�r rotationen och molnet renderas i full
detaljrikedom. 

Om du vill se en st�rre bild g�r det naturligtvis utm�rkt att
g�ra programf�nstret st�rre, men d� f�r du r�kna med att det ocks� blir f�rre
bildrutor per sekund som visas i och med att det blir fler bildpunkter f�r
programmet att fylla.

Mycket n�je!



REFERENSER OCH RESURSER
================================================================================
I VolumeClouds har jag utnyttjat Stefan Gustavsons implementation av simplex
noise fr�n 2004/2005. Hans filer kan du troligen ladda ned fr�n:
http://www.itn.liu.se/~stegu/TNM022-2005/lab3/GLSL-noise.zip

VolumeClouds anv�nder libglsl 0.9.4 som �r skrivet av Martin Christen. Du hittar
det p� adressen:
http://www.clockworkcoders.com/oglsl/downloads.html

Projektrapporten som jag skrev i samband med VolumeClouds hittar bland mina
artiklar p�:
http://www.fjeldstad.se
