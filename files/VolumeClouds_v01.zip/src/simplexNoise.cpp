/*
 * The contents of this file are for the most part copied from the demo
 * of GLSL Simplex Noise written by Stefan Gustavson (stegu@itn.liu.se).
 * Some modifications have been made to make the code fit the VolumeClouds
 * project.
 *
 * The comments in this file are made by Stefan Gustavson if nothing else
 * is stated.
 *
 * Anders Fjeldstad (andfj645@student.liu.se)
 * 2006-01-07
 */

#include <GL/glew.h>
#include <GL/glfw.h>
#include <GL/glext.h>
#include <cstdlib>
#include "simplexNoise.h"
using namespace std;

/*
 * initPermTexture(GLuint *texID) - create and load a 2D texture for
 * a combined index permutation and gradient lookup table.
 * This texture is used for 2D and 3D noise, both classic and simplex.
 */
void initPermTexture(GLuint *texID)
{
  	char *pixels;
  	int i,j;
  
  	glGenTextures(1, texID); // Generate a unique texture ID
  	glBindTexture(GL_TEXTURE_2D, *texID); // Bind the texture to texture unit 0

  	pixels = (char*)malloc( 256*256*4 );
  	for(i = 0; i<256; i++)
    	for(j = 0; j<256; j++) {
      		int offset = (i*256+j)*4;
      		char value = perm[(j+perm[i]) & 0xFF];
      		pixels[offset] = grad3[value & 0x0F][0] * 64 + 64;   // Gradient x
      		pixels[offset+1] = grad3[value & 0x0F][1] * 64 + 64; // Gradient y
      		pixels[offset+2] = grad3[value & 0x0F][2] * 64 + 64; // Gradient z
      		pixels[offset+3] = value;                     // Permuted index
    	}
  
  	// GLFW texture loading functions won't work here - we need GL_NEAREST lookup.
  	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels );
  	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
  	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
}

/*
 * initGradTexture(GLuint *texID) - create and load a 2D texture
 * for a 4D gradient lookup table. This is used for 4D noise only.
 */
void initGradTexture(GLuint *texID)
{
  	char *pixels;
  	int i,j;
  
  	glActiveTexture(GL_TEXTURE1); // Activate a different texture unit (unit 1)

  	glGenTextures(1, texID); // Generate a unique texture ID
  	glBindTexture(GL_TEXTURE_2D, *texID); // Bind the texture to texture unit 2

  	pixels = (char*)malloc( 256*256*4 );
  	for(i = 0; i<256; i++)
    	for(j = 0; j<256; j++) {
      		int offset = (i*256+j)*4;
      		char value = perm[(j+perm[i]) & 0xFF];
      		pixels[offset] = grad4[value & 0x1F][0] * 64 + 64;   // Gradient x
      		pixels[offset+1] = grad4[value & 0x1F][1] * 64 + 64; // Gradient y
      		pixels[offset+2] = grad4[value & 0x1F][2] * 64 + 64; // Gradient z
      		pixels[offset+3] = grad4[value & 0x1F][3] * 64 + 64; // Gradient w
    	}
  
  	// GLFW texture loading functions won't work here - we need GL_NEAREST lookup.
  	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels );
  	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
  	glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );

  	glActiveTexture(GL_TEXTURE0); // Switch active texture unit back to 0 again
}
