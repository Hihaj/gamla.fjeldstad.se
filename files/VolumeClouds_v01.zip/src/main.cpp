#include <iostream>
#include <fstream>
#include <cmath>
#include "glsl.h"
#include <GL/glfw.h>
#include <GL/glext.h>
#include "simplexNoise.h"
using namespace std;

void init();
void drawCuttingPlanes(GLint, GLint, GLfloat);
void drawPlane(GLint, GLfloat);
void updateRotation();
void setupCamera();
void render();
void showFPS();
int main(int, char**);

const GLint NUMBER_OF_PLANES = 32;
const GLint PLANE_RESOLUTION = 32;
const GLfloat VOLUME_SIDELENGTH = 3.0f;
const GLfloat SUN_POSITION[3] = {-1.0f, 1.0f, -1.0f};

GLfloat MOUSE_SENSITIVITY = 0.2;
GLfloat PI = 3.1415926535f;
GLfloat DEG2RAD = PI/180.0f;

GLfloat angleX = 0.0f;
GLfloat angleY = 0.0f;
GLfloat rotations[16] = {1.0f, 0.0f, 0.0f, 0.0f,
						 0.0f, 1.0f, 0.0f, 0.0f,
						 0.0f, 0.0f, 1.0f, 0.0f,
						 0.0f, 0.0f, 0.0f, 1.0f};
bool leftMousePressed = GL_FALSE;
GLint mouseOldX = 0;
GLint mouseOldY = 0;

bool drawCoordinateAxes = GL_FALSE;

int frames = 0;
double oldTime = 0; 
char titlestring[200];

glShaderManager shaderManager;
glShader * shader = 0;

/*
 * void initGL()
 *
 * Initializes OpenGL.
 */
void initGL() {
	glEnable(GL_TEXTURE_1D);
    glEnable(GL_TEXTURE_2D);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);	
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glClearColor(0.2f, 0.2f, 0.8f, 0.0f);
	//glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
}

/*
 * void drawCuttingPlanes(GLint numPlanes, 
 *					   	  GLint planeResolution, 
 *					      GLfloat volSideLength)
 *
 * Draws the planes that cut through the volume. The planes are always square
 * and should be drawn to always face the viewer (so that they are parallel to
 * the view plane at all times). The volume is assumed to be cubic and the
 * planes will be spaced evenly depthwise. 
 *
 * GLint numPlanes: 		The number of planes.
 * GLint planeResolution: 	The resolution of each plane. This means the number
 *							of vertices along a side of the plane.
 * GLfloat volSideLength:	The side length of the volume.
 */
void drawCuttingPlanes(GLint numPlanes, 
					   GLint planeResolution, 
					   GLfloat volSideLength) {
					
	// Calculate starting point in the z direction		
	GLfloat startZ = -volSideLength/2;
	
	// Calculate distance between adjacent planes
	GLfloat distance = volSideLength/(numPlanes-1);
	
	for (int plane = 0; plane < numPlanes; plane++) {
		glPushMatrix();
		glTranslatef(0.0f, 0.0f, startZ + plane*distance);
		shader->setUniform1f("zPosition", startZ + plane*distance);
		drawPlane(planeResolution, volSideLength);
		glPopMatrix();
	}
}

/*
 * void drawPlane(GLint resolution,
 *			      GLfloat sideLength)
 *
 * Draws a plane with the given resolution and side length. The plane will be
 * a square located in the xy-plane.
 *
 * GLint resolution: 	The resolution of the plane. This means the number
 *						of vertices along a side of the plane.
 * GLfloat sideLength:	The side length of the plane.
 */
void drawPlane(GLint resolution,
			   GLfloat sideLength) {
			
	// Calculate the starting point, which is in the third quadrant.		
	GLfloat startX = -sideLength/2;
	GLfloat startY = startX;
	
	// Calculate the step length (distance between vertices)
	GLfloat step = sideLength/(resolution-1);
	
	// Draw the plane using quad strips
	for (int strip = 0; strip < resolution-1; strip++) {
		glBegin(GL_QUAD_STRIP);
		for (int segment = 0; segment < resolution; segment++) {
			glVertex3f(startX + segment*step, startY + (strip+1)*step, 0.0f);
			glVertex3f(startX + segment*step, startY + strip*step, 0.0f);
		}
		glEnd();
	}
}

void updateRotation() {
	// Get current mouse coordinates
	GLint mouseX, mouseY;
	glfwGetMousePos(&mouseX, &mouseY);
	
	// Calculate new rotation angles for the volume
	angleY += MOUSE_SENSITIVITY*(mouseX - mouseOldX);
	angleX += MOUSE_SENSITIVITY*(mouseY - mouseOldY);
	
	// Create a rotation matrix corresponding to the rotations
	GLfloat radX = -DEG2RAD*angleX;
	GLfloat radY = -DEG2RAD*angleY;
	
	rotations[0] = cos(radY);
	rotations[2] = -sin(radY);
	rotations[4] = sin(radX)*sin(radY);
	rotations[5] = cos(radX);
	rotations[6] = sin(radX)*cos(radY);
	rotations[8] = cos(radX)*sin(radY);
	rotations[9] = -sin(radX);
	rotations[10] = cos(radX)*cos(radY);
	
	// Save the current mouse coordinates for next call
	mouseOldX = mouseX;
	mouseOldY = mouseY;
}

void setupCamera() {
	int width, height;
    glfwGetWindowSize(&width, &height);
    height = height <= 0 ? 1 : height;
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat)width/(GLfloat)height, 1.0f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0f, 0.0f, 3.0f,   // Eye position
              0.0f, 0.0f, 0.0f,   // View point
              0.0f, 1.0f, 0.0f);  // Up vector
}

/*
 * void render()
 *
 * Renders the scene to the draw buffer.
 */
void render() {
	
	// Draw coordinate axes rotated according to mouse movement
	if (leftMousePressed) {
		glDisable(GL_TEXTURE_1D);
	    glDisable(GL_TEXTURE_2D);
		glPushMatrix();
		glRotatef(angleX, 1.0f, 0.0f, 0.0f);
		glRotatef(angleY, 0.0f, 1.0f, 0.0f);
		
		glBegin(GL_LINES);
		glColor3f(0.0f, 1.0f, 0.0f);
		glVertex3f(0.0f, 100.0f, 0.0f);
		glVertex3f(0.0f, -100.0f, 0.0f);
		
		glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f(-100.0f, 0.0f, 0.0f);
		glVertex3f(100.0f, 0.0f, 0.0f);
		
		glColor3f(0.0f, 0.0f, 1.0f);
		glVertex3f(0.0f, 0.0f, -100.0f);
		glVertex3f(0.0f, 0.0f, 100.0f);
		glEnd();
		glPopMatrix();
		glEnable(GL_TEXTURE_1D);
	    glEnable(GL_TEXTURE_2D);
	}
	
	shader->begin();
	// Indicate whether noise/turbulence should be used. Noise is disabled
	// during interaction because of the need for higher framerates.
	shader->setUniform1i("useNoise", leftMousePressed ? 0 : 1);
	
	// Permutation and gradient textures used by the noise functions in the
	// fragment shader.
	shader->setUniform1i("permTexture", 0);
	shader->setUniform1i("gradTexture", 1);
	
	// The rotation matrix that depends on the mouse movements is sent to
	// the vertex shader column by column. A matrix should have been used
	// instead, but I never got it to work so this had to do.
	shader->setUniform4f("rotCol0", rotations[0], rotations[1], rotations[2], rotations[3]);
	shader->setUniform4f("rotCol1", rotations[4], rotations[5], rotations[6], rotations[7]);
	shader->setUniform4f("rotCol2", rotations[8], rotations[9], rotations[10], rotations[11]);
	shader->setUniform4f("rotCol3", rotations[12], rotations[13], rotations[14], rotations[15]);
	
	// Send the position of the lightsource (the sun) to the shaders.
	shader->setUniform3f("lightPos", SUN_POSITION[0], 
									 SUN_POSITION[1], 
									 SUN_POSITION[2]);
	// Draw the cutting planes
	drawCuttingPlanes(NUMBER_OF_PLANES, 
					  PLANE_RESOLUTION, 
					  VOLUME_SIDELENGTH);
	shader->end();
}

void showFPS() {
    double t, fps;
    t = glfwGetTime();
    if((t-oldTime) > 1.0 || frames == 0) {
        fps = (double)frames / (t-oldTime);
        sprintf(titlestring, "VolumeClouds 0.1 (%.1f FPS)", fps);
        glfwSetWindowTitle(titlestring);
        oldTime = t;
        frames = 0;
    }
    frames++;
}

/*
 * int main(int argc, char *argv[])
 *
 * The main function. Initializes GLFW, opens up a window and starts the main
 * loop which calls the render function.
 */
int main(int argc, char *argv[]) {
    bool running = GL_TRUE;
    
    // Redirect cout to a file for error output
    ofstream fileStream;
    fileStream.open("logfile.txt");
    streambuf * originalCoutBuf = cout.rdbuf();
    cout.rdbuf(fileStream.rdbuf());
    
    // Init GLFW
    glfwInit();
    
    // Try to open a window
    if(!glfwOpenWindow(400, 300, 8, 8, 8, 8, 32, 0, GLFW_WINDOW)) {
        glfwTerminate();
        return 1;
    }
    
    // Init OpenGL
    initGL();
    
    // Init OpenGL extensions
    initGLExtensions();
    
    // Load vertex and fragment shader
	shader = shaderManager.loadfromFile("VolumeClouds.vert", 
										"VolumeClouds.frag");
	if (shader == 0) {
		cout.rdbuf(originalCoutBuf);
		glfwTerminate();
		return 1;
	}
	
	// Create and load the noise textures (generated, not read from a file)
    initPermTexture(&permTextureID);
    initGradTexture(&gradTextureID);
    
    // Turn off sync with vertical monitor refreshes
    glfwSwapInterval(0);    
    
    glfwEnable(GLFW_STICKY_KEYS);
    
    // Main loop
    while (running) {
		// Draw number of frames per second to the window title bar
		showFPS();
		
		// Clear the draw buffer from color and depth info
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		// Setup the camera
		setupCamera();
		
		// Render the scene to the draw buffer
		render();
		
		// Swap buffers
		glfwSwapBuffers();	
		
		// Handle mouse input
		if (glfwGetMouseButton(GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS) {
			if (!leftMousePressed) {
				glfwGetMousePos(&mouseOldX, &mouseOldY);
			}
			leftMousePressed = GL_TRUE;
			updateRotation();
		} else {
			leftMousePressed = GL_FALSE;
		}
		
		// Check whether the program should exit
		if (glfwGetKey(GLFW_KEY_ESC) || !glfwGetWindowParam(GLFW_OPENED)) {
        	running = GL_FALSE;
		}
	}
	
	// Restore cout to original destination buffer
	cout.rdbuf(originalCoutBuf);
    
    // Terminate the window and exit program
    glfwTerminate();
    return 0;
}
