<?php
	/*
	 * Bildviz 0.2
	 *
	 * Anders Fjeldstad
	 * botta@home.se
	 *
	 * Bildviz �r ett mycket enkelt bildgalleri som l�ter dig enkelt visa upp
	 * kataloger med bildinneh�ll p� din webbplats. Det enda du beh�ver g�ra �r
	 * att st�lla in i vilken katalog som alla bildkataloger ligger samt att
	 * s�ga hur stora thumbnailbilderna ska vara. Bildviz g�r vid varje k�rning
	 * igenom dina bildkataloger och skapar eller tar bort thumbnailbilder.
	 *
	 * Det �r helt okej att kopiera, anv�nda, modifiera och sprida Bildviz
	 * s� l�nge som denna inledande kommentar finns med �verst i alla filer.
	 *
	 * F�r att fungera kr�ver Bildviz att PHP-biblioteket GD �r aktiverat p�
	 * webbservern. Detta beh�vs f�r att skapa thumbnailbilder. Dessutom m�ste
	 * PHP/webbservern ha skrivr�ttigheter till thumbnailkatalogen.
	 *
	 * T�nk p� att du inte kan ha vilka tecken som helst i dina katalognamn.
	 * F�r att Bildviz ska kunna hitta dina bilder f�r katalognamnen bara inne-
	 * h�lla tecknen 0-9, a-z, A-Z, -, _. Det kan h�nda att andra tecken ocks�
	 * funkar, men varf�r chansa?
	 *
	 * Dessa filer ing�r i Bildviz 0.2:
	 *
	 *    index.php				Sj�lva gallerisidan som visar alla thumbnails.
	 *    bygg.php				Scriptet som skapar/tar bort thumbnails.
	 *    installningar.php	    H�r g�r du inst�llningar f�r Bildviz.
	 *    visa.php              Denna fil visar upp bilder i full storlek.
	 *    vanster.gif
	 *    upp.gif
	 *    hoger.gif
	 *
	 */	
	
	// Starta output buffering och sessionst�d
	ob_start();
	session_start();
	
	// L�s in inst�llningar
	require_once('installningar.php');

	// G� igenom bildkatalogstrukturen och synka mot thumbnailkatalogstrukturen.
	if (strlen($_SESSION['jobb']) == 0) {
		
		// Scanna bildkatalogen och leta efter thumbnails att skapa.
		$_SESSION['attSkapaThumbsAv'] = array();
		scannaKatalog($BILDROT, $BILDROT, $THUMBSROT);	
		
		// G� igenom thumbnailkatalogen och ta bort thumbnails som inte har
		// motsvarande bilder i bildkatalogen.	
		rensaThumbs($THUMBSROT, $BILDROT, $THUMBSROT);
		
		// Om det finns thumbnails att skapa, ladda om scriptet.
		if (count($_SESSION['attSkapaThumbsAv']) > 0) {
			$_SESSION['jobb'] = implode('|', $_SESSION['attSkapaThumbsAv']);
			$_SESSION['attSkapaThumbsAv'] = '';
			header('Location: bygg.php');
			exit();
			
		// Annars, skriv ut ett meddelande som ber�ttar f�r anv�ndaren att
		// allt �r klart.
		} else {
			$allaOperationerKlara = true;
		}
		
	// G� igenom alla bilder som lagts p� k� och skapa thumbnails.
	} else {
		$attSkapaThumbsAv = explode('|', $_SESSION['jobb']);
		$anropstid = time();
		while ((count($attSkapaThumbsAv) > 0) && (time() - $anropstid < 20)) {
			$bildfil = array_pop($attSkapaThumbsAv);
			echo 'F�rfluten tid: ' . (time() - $anropstid) . '<br/>';
			echo 'Skapar thumbnail f�r ' . $bildfil . ', ' . $BILDROT . ', ' . $THUMBSROT . '<br/>';
			skapaThumb($bildfil, $BILDROT, $THUMBSROT, 
					   $THUMBNAILSTORLEK, $THUMBNAILKVALITET);
		}
		
		// Om alla thumbnails skapats, s�g till att det �r klart!
		if (count($attSkapaThumbsAv) == 0) {
			$_SESSION['jobb'] = '';
			
		// Om det finns thumbs kvar att skapa, lagra en ny str�ng med bildnamn.
		} else {
			$_SESSION['jobb'] = implode('|', $attSkapaThumbsAv);
		}
		
		// Ladda om scriptet efter 20 sekunder f�r att undvika att PHP:s
		// exekveringstidsgr�ns �verskrids, alternativt ladda om n�r alla
		// thumbnails skapats.
		header('Location: bygg.php');
		exit();
	}
	
	/*
	 * scannaKatalog($katalog, $bildrot, $thumbsrot)
	 *
	 * G�r rekursivt igenom underkataloger och filer i den angivna katalogen
	 * och kollar om de bilder som hittas finns i motsvarande struktur
	 * i thumbnailkatalogen.
	 */
	function scannaKatalog($katalog, $bildrot, $thumbsrot) {
		// L�s in alla underkataloger.
		$underkataloger = glob($katalog . '/*', GLOB_ONLYDIR);
		for ($i = 0; $i < count($underkataloger); $i++) {
			// Kolla om motsvarande thumbs-katalog finns, om inte skapa.
			$thumbskat = str_replace($bildrot, $thumbsrot, $underkataloger[$i]);
			if (!file_exists($thumbskat)) {
				mkdir($thumbskat);
			}
			
			// Scanna underkataloger rekursivt.
			scannaKatalog($underkataloger[$i], $bildrot, $thumbsrot);
		}
		
		// L�s in alla bildfiler av typ jpg, png och gif.
		$filer = glob($katalog . '/{*.jpg,*.JPG,*.png,*.PNG,*.gif,*.GIF}', GLOB_BRACE);
		for ($i = 0; $i < count($filer); $i++) {
			// Kolla om bilden har en thumbnail, annars l�ggs den p� k�.
			$thumb = str_replace($bildrot, $thumbsrot, $filer[$i]);
			$thumb = substr_replace($thumb, 'jpg', -3, 3);
			if (!file_exists($thumb)) {
				array_push($_SESSION['attSkapaThumbsAv'], $filer[$i]);
			}
		}
	}
	
	/*
	 * rensaThumbs($katalog, $bildrot, $thumbsrot)
	 *
	 * G�r rekursivt igenom alla underkataloger och filer i thumbskatalogen
	 * och tar bort dem om de inte har en motsvarighet i bildkatalogen.
	 */
	function rensaThumbs($katalog, $bildrot, $thumbsrot) {
		// L�s in alla underkataloger.
		$underkataloger = glob($katalog . '/*', GLOB_ONLYDIR);
		for ($i = 0; $i < count($underkataloger); $i++) {
			// Kolla om motsvarande bildkatalog finns, om inte ta bort.
			$bildkat = str_replace($thumbsrot, $bildrot, $underkataloger[$i]);
			if (!file_exists($bildkat)) {
				taBortKatalog($underkataloger[$i]);
				
			} else {
				// Scanna underkataloger rekursivt.
				rensaThumbs($underkataloger[$i], $bildrot, $thumbsrot);
			}
		}
		
		// L�s in alla bildfiler av typ jpg, png och gif.
		$filer = glob($katalog . '/{*.jpg,*.JPG,*.png,*.PNG,*.gif,*.GIF}', GLOB_BRACE);
		for ($i = 0; $i < count($filer); $i++) {
			// Kolla om motsvarande bild finns, annars tars thumbnailen bort.
			$bildjpg = str_replace($thumbsrot, $bildrot, $filer[$i]);
			$bildJPG = substr_replace($bildjpg, 'JPG', -3, 3);
			$bildpng = substr_replace($bildjpg, 'png', -3, 3);
			$bildPNG = substr_replace($bildjpg, 'PNG', -3, 3);
			$bildgif = substr_replace($bildjpg, 'gif', -3, 3);
			$bildGIF = substr_replace($bildjpg, 'GIF', -3, 3);
			if (!file_exists($bildjpg) && !file_exists($bildJPG) &&
				!file_exists($bildpng) && !file_exists($bildPNG) &&
				!file_exists($bildgif) && !file_exists($bildGIF)) {
					
				unlink($filer[$i]);
			}
		}
	}
	
	/*
	 * taBortKatalog($katalog)
	 *
	 * Tar rekursivt bort alla filer och underkataloger och avslutar med att
	 * ta bort sj�lva katalogen.
	 */
	function taBortKatalog($katalog) {
		// Rekursiv borttagning av underkataloger
		$underkataloger = glob($katalog . '/*', GLOB_ONLYDIR);
		for ($i = 0; $i < count($underkataloger); $i++) {
			taBortKatalog($underkataloger[$i]);
		}
		
		// Borttagning av filer i denna katalog
		$filer = glob($katalog . '/*.*');
		for ($i = 0; $i < count($filer); $i++) {
			unlink($filer[$i]);
		}
		
		// Ta bort denna katalog
		rmdir($katalog);
	}
	
	/*
	 * skapaThumb($bildfil, $bildrot, $thumbsrot)
	 *
	 * Skapar en thumbnail till den angivna bildfilen och placerar den p�
	 * motsvarande st�lle i thumbskatalogstrukturen.
	 */
	function skapaThumb($bildfil, $bildrot, $thumbsrot, $thumbstorlek, $thumbkvalitet) {
		$thumbfil = str_replace($bildrot, $thumbsrot, $bildfil);
		$thumbfil = substr_replace($thumbfil, 'jpg', -3, 3);
		
		if (exif_imagetype($bildfil) == IMAGETYPE_GIF) {
			$bild = imagecreatefromgif($bildfil);

		} elseif (exif_imagetype($bildfil) == IMAGETYPE_PNG) {
			$bild = imagecreatefrompng($bildfil);

		} elseif (exif_imagetype($bildfil) == IMAGETYPE_JPEG) {
			$bild = imagecreatefromjpeg($bildfil);

		} else {
			echo 'Kunde inte skapa thumbnail f�r ' . $bildfil . ' eftersom ' .
				 'formatet inte st�ds av Bildviz.<br/>';
			return;
		}
		
		// R�kna ut dimensioner f�r thumbnailbilden.
		$bildB = imagesx($bild);
		$bildH = imagesy($bild);
		$ratio = $bildB / $bildH;
		$thumbB = round($bildB > $bildH ? $thumbstorlek : $ratio*$thumbstorlek);
		$thumbH = round($bildB > $bildH ? $thumbstorlek/$ratio : $thumbstorlek);
		
		// Skapa och spara thumbnailbild.
		$thumb = imagecreatetruecolor($thumbB, $thumbH);
		imagecopyresampled($thumb, $bild, 0, 0, 0, 0, $thumbB, $thumbH, $bildB, $bildH);
		imagejpeg($thumb, $thumbfil, $thumbkvalitet);
	}
?>
<?php if ($allaOperationerKlara) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Bildviz 0.2</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
		<meta name="author" content="Anders Fjeldstad"/>
		<style type="text/css">
			body {
				background-color: #FFFFFF;
				margin: 30px;
			}
			
			h3 {
				font-family: "Trebuchet MS", Verdana, sans-serif;
				font-size: 16px;
				font-weight: bold;
				color: #345678;
				margin: 20px 0px 5px 0px;
			}
			
			p {
				font-family: "Trebuchet MS", Verdana, sans-serif;
				font-size: 12px;
				color: #000000;
				margin: 0px 0px 10px 0px;
				width: 300px;
			}
			
			a {
				color: #876543;
				text-decoration: none;
			}
			
			a:hover {
				text-decoration: underline;
			}
		</style>
	</head>
	<body>
		<h3>Alla operationer klara</h3>
		<p>
			Bildviz har nu g�tt igenom dina bildkataloger och skapat thumbnails
			f�r de nya bilderna samt tagit bort gamla thumbnails som inte l�ngre
			har n�gra bilder.
		</p>
		<p>
			<a href="index.php">Klicka h�r</a> f�r att titta i galleriet!
		</p>
	</body>
</html>
<?php } ?>
