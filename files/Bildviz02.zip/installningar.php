<?php	
	/*
	 * Bildviz 0.2
	 *
	 * Anders Fjeldstad
	 * botta@home.se
	 *
	 * Bildviz �r ett mycket enkelt bildgalleri som l�ter dig enkelt visa upp
	 * kataloger med bildinneh�ll p� din webbplats. Det enda du beh�ver g�ra �r
	 * att st�lla in i vilken katalog som alla bildkataloger ligger samt att
	 * s�ga hur stora thumbnailbilderna ska vara. Bildviz g�r vid varje k�rning
	 * igenom dina bildkataloger och skapar eller tar bort thumbnailbilder.
	 *
	 * Det �r helt okej att kopiera, anv�nda, modifiera och sprida Bildviz
	 * s� l�nge som denna inledande kommentar finns med �verst i alla filer.
	 *
	 * F�r att fungera kr�ver Bildviz att PHP-biblioteket GD �r aktiverat p�
	 * webbservern. Detta beh�vs f�r att skapa thumbnailbilder. Dessutom m�ste
	 * PHP/webbservern ha skrivr�ttigheter till thumbnailkatalogen.
	 *
	 * T�nk p� att du inte kan ha vilka tecken som helst i dina katalognamn.
	 * F�r att Bildviz ska kunna hitta dina bilder f�r katalognamnen bara inne-
	 * h�lla tecknen 0-9, a-z, A-Z, -, _. Det kan h�nda att andra tecken ocks�
	 * funkar, men varf�r chansa?
	 *
	 * Dessa filer ing�r i Bildviz 0.2:
	 *
	 *    index.php				Sj�lva gallerisidan som visar alla thumbnails.
	 *    bygg.php				Scriptet som skapar/tar bort thumbnails.
	 *    installningar.php	    H�r g�r du inst�llningar f�r Bildviz.
	 *    visa.php              Denna fil visar upp bilder i full storlek.
	 *    vanster.gif
	 *    upp.gif
	 *    hoger.gif
	 *
	 */	
	
	// Max sidl�ngd p� thumbnailbild i pixlar.
	$THUMBNAILSTORLEK = 150;	
	
	// Kvalitet p� thumbnailbilderna, skala 1-100
	$THUMBNAILKVALITET = 60;
	
	// S�kv�g till bildrotkatalog relativt Bildviz.
	$BILDROT = './bilder';	

	// S�kv�g till den katalog d�r thumbnailbilderna ska l�ggas. Observera att 
	// PHP/webbservern m�ste ha skrivr�ttigheter i denna katalog.
	$THUMBSROT = './thumbs';	
?>
