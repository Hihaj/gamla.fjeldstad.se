<?php
	/*
	 * Bildviz 0.2
	 *
	 * Anders Fjeldstad
	 * botta@home.se
	 *
	 * Bildviz �r ett mycket enkelt bildgalleri som l�ter dig enkelt visa upp
	 * kataloger med bildinneh�ll p� din webbplats. Det enda du beh�ver g�ra �r
	 * att st�lla in i vilken katalog som alla bildkataloger ligger samt att
	 * s�ga hur stora thumbnailbilderna ska vara. Bildviz g�r vid varje k�rning
	 * igenom dina bildkataloger och skapar eller tar bort thumbnailbilder.
	 *
	 * Det �r helt okej att kopiera, anv�nda, modifiera och sprida Bildviz
	 * s� l�nge som denna inledande kommentar finns med �verst i alla filer.
	 *
	 * F�r att fungera kr�ver Bildviz att PHP-biblioteket GD �r aktiverat p�
	 * webbservern. Detta beh�vs f�r att skapa thumbnailbilder. Dessutom m�ste
	 * PHP/webbservern ha skrivr�ttigheter till thumbnailkatalogen.
	 *
	 * T�nk p� att du inte kan ha vilka tecken som helst i dina katalognamn.
	 * F�r att Bildviz ska kunna hitta dina bilder f�r katalognamnen bara inne-
	 * h�lla tecknen 0-9, a-z, A-Z, -, _. Det kan h�nda att andra tecken ocks�
	 * funkar, men varf�r chansa?
	 *
	 * Dessa filer ing�r i Bildviz 0.2:
	 *
	 *    index.php				Sj�lva gallerisidan som visar alla thumbnails.
	 *    bygg.php				Scriptet som skapar/tar bort thumbnails.
	 *    installningar.php	    H�r g�r du inst�llningar f�r Bildviz.
	 *    visa.php              Denna fil visar upp bilder i full storlek.
	 *    vanster.gif
	 *    upp.gif
	 *    hoger.gif
	 *
	 */	

	// L�s in inst�llningar
	require_once('installningar.php');
	
	// L�s in alla bildkataloger och deras bilder
	$bilder = array();
	lasInBildkatalog($BILDROT, $bilder, $BILDROT, $THUMBSROT);
	
	function lasInBildkatalog($katalog, &$bilder, $bildrot, $thumbsrot) {
		$underkataloger = glob($katalog . '/*', GLOB_ONLYDIR);
		for ($i = 0; $i < count($underkataloger); $i++) {
			// Kolla om motsvarande thumbs-katalog finns, om inte hoppa �ver.
			$thumbskat = str_replace($bildrot, $thumbsrot, $underkataloger[$i]);
			if (file_exists($thumbskat)) {
				lasInBildkatalog($underkataloger[$i], $bilder, $bildrot, $thumbsrot);
			}
		}
		
		// L�s in alla bildfiler av typ jpg, png och gif.
		$filer = glob($katalog . '/{*.jpg,*.JPG,*.png,*.PNG,*.gif,*.GIF}', GLOB_BRACE);
		for ($i = 0; $i < count($filer); $i++) {
			// Kolla om bilden har en thumbnail, om s� l�gg in i bildlistan.
			$thumb = str_replace($bildrot, $thumbsrot, $filer[$i]);
			$thumb = substr_replace($thumb, 'jpg', -3, 3);
			if (file_exists($thumb)) {
				array_push($bilder, array('katalog' => $katalog, 
										  'bild' => $filer[$i], 
										  'thumbnail' => $thumb));
			}
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Bildviz 0.2</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
		<meta name="author" content="Anders Fjeldstad"/>
		<style type="text/css">
			body {
				background-color: #AAAAAA;
				margin: 30px;
			}
			
			div.katalog {
				border: 1px solid #000000;
				background-color: #FFFFFF;
				margin-bottom: 20px;
				padding-bottom: 10px;
			}
			
			div.katalog h3 {
				font-family: "Trebuchet MS", Verdana, sans-serif;
				font-size: 26px;
				font-weight: bold;
				color: #FFFFFF;
				background-color: #CCCCCC;
				margin: 0px;
				padding: 5px 10px 5px 10px;
			}
			
			div.katalog a {
				float: left;
				display: inline;
				margin: 10px 0px 0px 10px;
				padding: 5px;
				border: 1px solid #DDDDDD;
				background-color: #EEEEEE;
				height: <?=$THUMBNAILSTORLEK?>px;
				width: <?=$THUMBNAILSTORLEK?>px;
				text-align: center;
			}
			
			div.katalog a:hover {
				border: 1px solid #345678;
				background-color: #DDDDDD;
			}
			
			div.katalog a img {
				border: 0px;
			}
			
		</style>
	</head>
	<body>
		<?php for ($i = 0, $bildindex = 0; $i < count($bilder); $i++, $bildindex++) {?>
		<?php if ($i == 0 || $bilder[$i]['katalog'] != $bilder[$i-1]['katalog']) { ?>
		<?php $bildindex = 0; ?>
		<div class="katalog">
			<h3><?=str_replace($BILDROT . '/', '', $bilder[$i]['katalog'])?></h3>
		<?php } ?>
			<a href="<?=htmlspecialchars('visa.php?katalog=' . $bilder[$i]['katalog'] . '&bild=' . $bildindex)?>"><img src="<?=$bilder[$i]['thumbnail']?>"/></a>
		<?php if ($i == count($bilder)-1 || $bilder[$i]['katalog'] != $bilder[$i+1]['katalog']) { ?>
			<div style="clear: both;"></div>
		</div>
		<?php } ?>
		<?php } ?>
	</body>
</html>
