<?php
	/*
	 * Bildviz 0.2
	 *
	 * Anders Fjeldstad
	 * botta@home.se
	 *
	 * Bildviz �r ett mycket enkelt bildgalleri som l�ter dig enkelt visa upp
	 * kataloger med bildinneh�ll p� din webbplats. Det enda du beh�ver g�ra �r
	 * att st�lla in i vilken katalog som alla bildkataloger ligger samt att
	 * s�ga hur stora thumbnailbilderna ska vara. Bildviz g�r vid varje k�rning
	 * igenom dina bildkataloger och skapar eller tar bort thumbnailbilder.
	 *
	 * Det �r helt okej att kopiera, anv�nda, modifiera och sprida Bildviz
	 * s� l�nge som denna inledande kommentar finns med �verst i alla filer.
	 *
	 * F�r att fungera kr�ver Bildviz att PHP-biblioteket GD �r aktiverat p�
	 * webbservern. Detta beh�vs f�r att skapa thumbnailbilder. Dessutom m�ste
	 * PHP/webbservern ha skrivr�ttigheter till thumbnailkatalogen.
	 *
	 * T�nk p� att du inte kan ha vilka tecken som helst i dina katalognamn.
	 * F�r att Bildviz ska kunna hitta dina bilder f�r katalognamnen bara inne-
	 * h�lla tecknen 0-9, a-z, A-Z, -, _. Det kan h�nda att andra tecken ocks�
	 * funkar, men varf�r chansa?
	 *
	 * Dessa filer ing�r i Bildviz 0.2:
	 *
	 *    index.php				Sj�lva gallerisidan som visar alla thumbnails.
	 *    bygg.php				Scriptet som skapar/tar bort thumbnails.
	 *    installningar.php	    H�r g�r du inst�llningar f�r Bildviz.
	 *    visa.php              Denna fil visar upp bilder i full storlek.
	 *    vanster.gif
	 *    upp.gif
	 *    hoger.gif
	 *
	 */	
	
	// L�s in inst�llningar
	require_once('installningar.php');
	
	// Kontrollera det aktuella katalognamnet, g� till indexsidan om det inte
	// �r giltigt.
	if (trim($_GET['katalog']) == '' || 
		!file_exists($_GET['katalog']) ||
		!ctype_digit($_GET['bild'])) {
			
		header('Location: index.php');
		exit();	
		
	// S�kerhetskontrollera katalogen, se till att man inte g�r ut ur bildroten.
	} else if (stristr(str_replace($BILDROT, '', $_GET['katalog']), '/../')) {
		header('Location: index.php');
		exit();	
	} 
	
	$katalog = trim($_GET['katalog']);
	$bild = $_GET['bild'];
	
	// L�s in alla bildfiler av typ jpg, png och gif.
	$filer = glob($katalog . '/{*.jpg,*.JPG,*.png,*.PNG,*.gif,*.GIF}', GLOB_BRACE);
	
	// Kolla om den valda bilden har en thumbnail, annars g� till index.
	$visaBild = false;
	if ($bild < count($filer)) {
		// Kolla om bilden har en thumbnail, om s� l�gg in i bildlistan.
		$thumb = str_replace($BILDROT, $THUMBSROT, $filer[$bild]);
		$thumb = substr_replace($thumb, 'jpg', -3, 3);
		if (file_exists($thumb)) {
			$visaBild = true;
		}
	}
	
	if (!$visaBild) {
		header('Location: index.php');
		exit();	
	} 
	
	// Skapa l�nkar f�r fram�t och bak�t
	$nastaBild = false;
	$foregaendeBild = false;
	if ($bild < count($filer)-1) {
		$nastaBild = 'visa.php?katalog=' . $katalog . '&bild=' . ($bild+1);
	}
	if ($bild > 0) {
		$foregaendeBild = 'visa.php?katalog=' . $katalog . '&bild=' . ($bild-1);
	}
	
	// H�mta bildens storlek
	list($bildB, $bildH, $typ, $attribut) = getimagesize($filer[$bild]);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Bildviz 0.2</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
		<meta name="author" content="Anders Fjeldstad"/>
		<style type="text/css">
			body {
				background-color: #AAAAAA;
				margin: 30px;
			}
			
			div.katalog {
				border: 1px solid #000000;
				background-color: #FFFFFF;
				margin-bottom: 20px;
				padding-bottom: 10px;
				width: <?=($bildB + 30 >= 150 ? $bildB + 30 : 150)?>px;
			}
			
			div.katalog h3 {
				font-family: "Trebuchet MS", Verdana, sans-serif;
				font-size: 26px;
				font-weight: bold;
				color: #FFFFFF;
				background-color: #CCCCCC;
				margin: 0px;
				padding: 5px 10px 5px 10px;
			}
			
			div.katalog h3 a {
				float: left;
				width: 40px;
				height: 40px;
				margin: 0px;
				padding: 0px;
				background-color: #DDDDDD;
				text-decoration: none;
				border: 0px;
			}
			
			div.katalog h3 a:hover {
				background-color: #EEEEEE;
				border: 0px;
			}
			
			div.katalog h3 a img {
				border: 0px;
				margin: 0px;
			}
			
			div.katalog a {
				float: left;
				display: inline;
				margin: 10px 0px 0px 10px;
				padding: 5px;
				border: 1px solid #DDDDDD;
				background-color: #EEEEEE;
				width: <?=$bildB?>px;
				height: <?=$bildH?>px;
				text-align: center;
			}
			
			div.katalog a:hover {
				border: 1px solid #345678;
				background-color: #DDDDDD;
			}
			
			div.katalog a img {
				border: 0px;
			}
			
		</style>
	</head>
	<body>
		<div class="katalog">
			<h3>
				<?php if ($foregaendeBild) { ?>
				<a href="<?=htmlspecialchars($foregaendeBild)?>"><img src="vanster.gif"/></a>				
				<?php } ?>
				<a style="margin: 0px 5px 0px 5px;" href="<?=htmlspecialchars('index.php')?>"><img src="upp.gif"/></a>
				<?php if ($nastaBild) { ?>
				<a href="<?=htmlspecialchars($nastaBild)?>"><img src="hoger.gif"/></a>				
				<?php } ?>
				<div style="clear: both;"/>
			</h3>
			<?php if ($nastaBild) { ?>
			<a href="<?=htmlspecialchars($nastaBild)?>" alt="Klicka f�r att se n�sta bild"/><img src="<?=htmlspecialchars($filer[$bild])?>"/></a>
			<?php } else { ?>
			<a href="<?=htmlspecialchars('index.php')?>" alt="Klicka f�r att g� tillbaka till bildindex"/><img src="<?=htmlspecialchars($filer[$bild])?>"/></a>
			<?php } ?>
			<div style="clear: both;"/>
		</div>
	</body>
</html>
